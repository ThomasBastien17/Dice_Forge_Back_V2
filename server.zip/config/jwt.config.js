const jwtConfig = {
    secretKey: '2dztl%-cv+@&dyjwz9848su!7wob316bn6op*ty9#&0gtuaz^', // Clé secrète pour signer les tokens JWT
    options: {
        expiresIn: '1h' // Token expirera après 1 heure
    }
};

export default jwtConfig;