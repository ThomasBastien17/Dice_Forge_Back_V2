-- Verify diceforge:init on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
