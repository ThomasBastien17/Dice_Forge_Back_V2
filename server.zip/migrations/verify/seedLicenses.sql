-- Verify diceforge:seedLicenses on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
